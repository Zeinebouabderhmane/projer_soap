from http.server import BaseHTTPRequestHandler, HTTPServer
import xml.etree.ElementTree as ET

HOST = "127.0.0.1"
PORT = 8000

SOAP_ENV_NS = "http://schemas.xmlsoap.org/soap/envelope/"
NSMAP = {"soapenv": SOAP_ENV_NS}

def build_soap_response(result: int) -> bytes:
    # SOAP 1.1 response with addResult
    xml = f"""<?xml version="1.0" encoding="utf-8"?>
<soapenv:Envelope xmlns:soapenv="{SOAP_ENV_NS}">
  <soapenv:Body>
    <addResponse>
      <addResult>{result}</addResult>
    </addResponse>
  </soapenv:Body>
</soapenv:Envelope>"""
    return xml.encode("utf-8")

class SoapHandler(BaseHTTPRequestHandler):
    def _set_headers(self, status=200):
        self.send_response(status)
        self.send_header("Content-Type", "text/xml; charset=utf-8")
        # CORS (important for browser fetch)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, SOAPAction")
        self.end_headers()

    def do_OPTIONS(self):
        # Preflight CORS
        self._set_headers(200)

    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        data = self.rfile.read(length)

        try:
            root = ET.fromstring(data)

            # Find SOAP Body
            body = root.find("soapenv:Body", NSMAP)
            if body is None or len(body) == 0:
                self._set_headers(400)
                self.wfile.write(build_soap_response(0))
                return

            # The first child inside Body is the operation element (ex: <add>...</add>)
            op = list(body)[0]

            # Read a and b (we accept with or without namespaces)
            a_el = op.find(".//a")
            b_el = op.find(".//b")
            if a_el is None or b_el is None:
                self._set_headers(400)
                self.wfile.write(build_soap_response(0))
                return

            a = int(a_el.text.strip())
            b = int(b_el.text.strip())
            result = a + b

            self._set_headers(200)
            self.wfile.write(build_soap_response(result))

        except Exception as e:
            self._set_headers(500)
            self.wfile.write(build_soap_response(0))

def main():
    print(f"SOAP Server running on http://{HOST}:{PORT}")
    httpd = HTTPServer((HOST, PORT), SoapHandler)
    httpd.serve_forever()

if __name__ == "__main__":
    main()
